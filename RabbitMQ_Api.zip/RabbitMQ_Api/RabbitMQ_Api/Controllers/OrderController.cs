﻿using Microsoft.AspNetCore.Mvc;
using RabbitMQ_Api.Domain.Interface;
using RabbitMQ_Api.Domain.Models;
using RabbitMQ_Api.Domain.Services;

namespace RabbitMQ_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private ILogger<OrderController> _logger;
        private readonly IRabbitMqService _rabbitMqService;

        public OrderController(ILogger<OrderController> logger, IRabbitMqService rabbitMqService)
        {
            _logger = logger;
            _rabbitMqService = rabbitMqService;
        }

        public IActionResult InsertOrder(Order order)
        {
            try
            {
                var response = _rabbitMqService.CallRabbitMq(order);
                return Accepted(response);
            }
            catch (Exception ex)
            {
                _logger.LogError("Erro ao tentar criar um novo pedido", ex);
                return new StatusCodeResult(500);
            }
        }
    }
}
