﻿using RabbitMQ_Api.Domain.Interface;
using RabbitMQ_Api.Domain.Services;

namespace RabbitMQ_Api.StartupConfig
{
    public static class RegisterDI
    {
        public static void RegisterDependencyInjection(this IServiceCollection services)
        {
            services.AddScoped<IRabbitMqService, RabbitMqService>();
        }
    }
}
