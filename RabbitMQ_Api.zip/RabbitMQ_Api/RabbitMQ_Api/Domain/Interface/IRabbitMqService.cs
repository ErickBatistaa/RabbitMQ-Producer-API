﻿using RabbitMQ_Api.Domain.Models;

namespace RabbitMQ_Api.Domain.Interface
{
    public interface IRabbitMqService
    {
        string CallRabbitMq(Order order);
    }
}
