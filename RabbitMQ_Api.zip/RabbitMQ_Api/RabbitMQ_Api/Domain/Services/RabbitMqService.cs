﻿using RabbitMQ.Client;
using RabbitMQ_Api.Domain.Interface;
using RabbitMQ_Api.Domain.Models;
using System.Text;

namespace RabbitMQ_Api.Domain.Services
{
    public class RabbitMqService : IRabbitMqService
    {
        public string CallRabbitMq(Order order)
        {
            var factory = new ConnectionFactory() { HostName = "localhost" };
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                channel.QueueDeclare(queue: "TESTE",
                                     durable: false,
                                     exclusive: false,
                                     autoDelete: false,
                                     arguments: null);

                string message = System.Text.Json.JsonSerializer.Serialize(order);
                var body = Encoding.UTF8.GetBytes(message);

                channel.BasicPublish(exchange: "",
                                     routingKey: "TESTE",
                                     basicProperties: null,
                                     body: body);

                return message;

            } 
        }
    }
}
